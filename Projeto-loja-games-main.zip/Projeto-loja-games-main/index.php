<?php
include_once("view/header.php");
?>
<img src="view/img/jogos.png" width="100%"/>

<?php
include_once("view/footer.php");
?>