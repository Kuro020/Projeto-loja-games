<?php
$url='localhost';
$usuario='root';
$senha='';
$nomeBanco='bdlojagamesti11t';

$conexao=mysqli_connect($url,$usuario,$senha,$nomeBanco);
?>