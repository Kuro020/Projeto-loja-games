<?php
include_once("header.php");
?>
<img src="img/jogos.png" width=100%>
<?php
include_once("footer.php");
?>